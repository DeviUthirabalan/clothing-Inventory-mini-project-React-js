import React, { useState } from "react";
import { Link } from "react-router-dom";
import products from "./../assets/product.json";

const Home = (props) => {
  let [cart, updateCart] = useState([]);
  console.log("props", props);
  return (
    <div style={{ width: "100%" }}>
      {console.log("state", cart)}
      {/* Card */}
      <div className="card-group" style={{ width: "100%" }}>
        <nav class="navbar navbar-light bg-dark" style={{ width: "100%" }}>
          <span
            style={{ fontStyle: "italic", color: "white", fontWeight: "bold" }}
          >
            Home
          </span>
        </nav>
        <div className="">
          <div
            className="card"
            style={{ margin: " 10px 20px 20px 20px", padding: "20px" }}
          >
            <div className="card-body" style={{ display: "flex" }}>
              {products.map((product) => (
                <div className="Products">
                  <h5 className="card-title"> {product.name} </h5>
                  <p>{product.price}</p>
                  <img
                    style={{ height: "200px", width: "200px" }}
                    src={product.image}
                    className="card-img-top"
                    alt="productImg"
                  />
                  <br />
                  <br />
                  <Link
                    className="btn btn-success"
                    to={{ pathname: "/orders", orderData: [product] }}
                  >
                    Order Now&nbsp;
                  </Link>
                  <br></br>
                  <button
                    className="btn btn-primary"
                    style={{ margin: "20px" }}
                    onClick={() => updateCart([...cart, product])}
                  >
                    Add to Cart
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
        <div style={{ float: "right", width: "100%" }}>
          <Link
            className="btn btn-success"
            to={{ pathname: "/Cart", cartData: cart }}
          >
            Go to Cart &nbsp;
            {cart && cart.length > 0 && (
              <span class="badge badge-danger">{cart.length}</span>
            )}
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Home;
