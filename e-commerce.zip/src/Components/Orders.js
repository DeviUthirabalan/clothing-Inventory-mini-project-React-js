import React from "react";
import products from "./../assets/product.json";
import { Link } from "react-router-dom";

const orders = (props) => {
  console.log("props", props);
  return (
    <div>
      <div style={{ width: "100%" }}>
        {
          <div className="card-group" style={{ width: "100%" }}>
            <nav class="navbar navbar-light bg-dark" style={{ width: "100%" }}>
              <span
                style={{
                  fontStyle: "italic",
                  color: "white",
                  fontWeight: "bold",
                }}
              >
                MyOrders &nbsp;
              </span>
            </nav>
            <div></div>
            <br></br>
            <div className="row">
              <div className="col" style={{ display: "flex" }}>
                <h1 style={{ textAlign: "center" }}>Thanks for Ordering!!</h1>
                <br />
                <div
                  style={{
                    display: "flex",
                    margin: " 10px 20px 20px 20px",
                    padding: "20px",
                  }}
                >
                  <div style={{ display: "flex" }}>
                    {console.log(props, props.location?.orderData)}
                    {props.location?.orderData?.map((product) => (
                      <div className="Products">
                        <h5 className="card-title">{product.name} </h5>
                        <p>{product.price}</p>
                        <img
                          src={product.image}
                          style={{ height: "200px", width: "200px" }}
                          className="card-img-top"
                          alt="productImg"
                        />
                        <p>{product.description}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
            <div style={{ float: "right", width: "100%" }}>
              <Link
                className="btn btn-success"
                to={{ pathname: "/home", cart: props.location?.cartData }}
              >
                Continue Shopping &nbsp;
              </Link>
            </div>
          </div>
        }
      </div>
    </div>
  );
};
export default orders;
