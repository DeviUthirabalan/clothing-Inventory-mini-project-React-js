import React, { useState } from "react";
import { Link } from "react-router-dom";
import products from "./../assets/product.json";

const Cart = (props) => {
  console.log("props", props);

  let [cart, updateCart] = useState(
    props.location && props.location.cartData ? props.location.cartData : []
  );

  let deleteProduct = (data) => {
    let updatedCart = cart.filter(function (product) {
      return product.name !== data.name;
    });
    updateCart(updatedCart);
  };

  return (
    <div style={{ width: "100%" }}>
      {console.log("state", cart)}
      {
        <div className="card-group" style={{ width: "100%" }}>
          <nav class="navbar navbar-light bg-dark" style={{ width: "100%" }}>
            <span
              style={{
                fontStyle: "italic",
                color: "white",
                fontWeight: "bold",
              }}
            >
              Cart &nbsp;
              {props.location?.cartData &&
                props.location.cartData.length > 0 && (
                  <span class="badge badge-danger">
                    {props.location.cartData.length}
                  </span>
                )}
            </span>
          </nav>
          <div className="row">
            <div className="col" style={{ display: "flex" }}>
              <div
                className="card"
                style={{
                  display: "flex",
                  margin: " 10px 20px 20px 20px",
                  padding: "20px",
                }}
              >
                <div className="card-body" style={{ display: "flex" }}>
                  {cart?.map((product) => (
                    <div className="Products">
                      <h5 className="card-title"> {product.name} </h5>
                      <p>{product.price}</p>
                      <img
                        src={product.image}
                        style={{ height: "200px", width: "200px" }}
                        className="card-img-top"
                        alt="productImg"
                      />
                      <br />
                      <br></br>
                      <button
                        className="btn btn-danger"
                        onClick={() => deleteProduct(product)}
                      >
                        Delete{" "}
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
          <div style={{ float: "right", width: "100%" }}>
            <Link
              className="btn btn-success"
              to={{ pathname: "/home", cart: props.location?.orderData }}
            >
              Back to home &nbsp;
              {cart.length > 0 && (
                <span class="badge badge-success">
                  {props.location.cartData.length}
                </span>
              )}
            </Link>{" "}
            &nbsp;
            <Link
              className="btn btn-success"
              to={{ pathname: "/orders", orderData: cart }}
            >
              Order Now&nbsp;
            </Link>
          </div>
        </div>
      }
    </div>
  );
};

export default Cart;
