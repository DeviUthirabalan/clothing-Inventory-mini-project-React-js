import logo from "./logo.svg";
import "./App.css";
import Home from "./Components/Home.js";
import Cart from "./Components/Cart";
import { useState } from "react";
import Orders from "./Components/Orders";
import ReactDOM from "react-dom";
import { BrowserRouter, Route, Link, Switch } from "react-router-dom"; 

function App() {
  var React = require("react");
  require("react-router-dom");

  return (
    <div className="App">
      <BrowserRouter>
        <Route exact path="/" component={Home} />
        <Route exact path="/Home" component={Home} />
        <Route path="/Cart" component={Cart} />
        <Route path="/Orders" component={Orders} />
      </BrowserRouter>
    </div>
  );
}

export default App;
